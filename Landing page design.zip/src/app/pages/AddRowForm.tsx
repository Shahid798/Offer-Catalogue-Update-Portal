import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Save, Sparkles } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Label } from '../components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { useCSV } from '../context/CSVContext';
import { toast } from 'sonner';

interface CSVData {
  headers: string[];
  rows: string[][];
}

interface FieldValue {
  mode: 'existing' | 'custom' | 'empty' | 'auto';
  value: string;
}

export default function AddRowForm() {
  const navigate = useNavigate();
  const { csvData, setCsvData } = useCSV();
  const [fieldValues, setFieldValues] = useState<Record<string, FieldValue>>({});

  useEffect(() => {
    if (csvData) {
      // Initialize field values with smart defaults
      const initialValues: Record<string, FieldValue> = {};
      csvData.headers.forEach((header, columnIndex) => {
        // Check if column is always populated (no empty values)
        const isAlwaysPopulated = isColumnAlwaysPopulated(columnIndex);
        
        initialValues[header] = { 
          mode: isAlwaysPopulated ? 'auto' : 'empty', 
          value: '' 
        };
      });
      setFieldValues(initialValues);
    }
  }, [csvData]);

  const isColumnAlwaysPopulated = (columnIndex: number): boolean => {
    if (!csvData) return false;
    
    // Check if all rows have a non-empty value in this column
    return csvData.rows.every(row => {
      const value = row[columnIndex];
      return value && value.trim() !== '';
    });
  };

  const getUniqueValuesForColumn = (columnIndex: number): string[] => {
    if (!csvData) return [];
    const values = csvData.rows
      .map(row => row[columnIndex])
      .filter(val => val && val.trim() !== '');
    return Array.from(new Set(values));
  };

  // Analyze pattern: check if column values are concatenation of other columns
  const analyzePattern = (columnIndex: number): { isPattern: boolean; sourceColumns?: number[] } => {
    if (!csvData || csvData.rows.length === 0) return { isPattern: false };

    const column = csvData.headers[columnIndex];
    const firstRowValue = csvData.rows[0][columnIndex];
    
    if (!firstRowValue) return { isPattern: false };

    // Try to find which columns contribute to this value
    // Check if it's a concatenation of other columns
    const potentialSources: number[] = [];
    
    for (let i = 0; i < csvData.headers.length; i++) {
      if (i === columnIndex) continue;
      
      const otherValue = csvData.rows[0][i];
      if (otherValue && firstRowValue.includes(otherValue)) {
        potentialSources.push(i);
      }
    }

    // Verify pattern across all rows
    if (potentialSources.length > 0) {
      const isConsistent = csvData.rows.every(row => {
        const targetValue = row[columnIndex];
        return potentialSources.every(srcIdx => {
          const srcValue = row[srcIdx];
          return srcValue && targetValue.includes(srcValue);
        });
      });

      if (isConsistent) {
        return { isPattern: true, sourceColumns: potentialSources };
      }
    }

    return { isPattern: false };
  };

  const generateAutoValue = (columnIndex: number, visited: Set<number> = new Set()): string => {
    if (!csvData) return '';
    
    // Prevent infinite recursion
    if (visited.has(columnIndex)) {
      return '';
    }
    
    visited.add(columnIndex);

    const header = csvData.headers[columnIndex];
    const pattern = analyzePattern(columnIndex);

    if (pattern.isPattern && pattern.sourceColumns) {
      // Build value from source columns
      let autoValue = '';
      pattern.sourceColumns.forEach(srcIdx => {
        const srcHeader = csvData.headers[srcIdx];
        const srcField = fieldValues[srcHeader];
        
        if (srcField) {
          let value = '';
          if (srcField.mode === 'auto') {
            value = generateAutoValue(srcIdx, visited);
          } else if (srcField.mode === 'existing' || srcField.mode === 'custom') {
            value = srcField.value;
          }
          
          if (value) {
            autoValue += value;
          }
        }
      });

      return autoValue;
    }

    // Check if all values are the same (constant)
    const uniqueValues = getUniqueValuesForColumn(columnIndex);
    if (uniqueValues.length === 1) {
      return uniqueValues[0];
    }

    // Check if this column matches another column (like pyName === pyLabel)
    for (let i = 0; i < csvData.headers.length; i++) {
      if (i === columnIndex) continue;
      
      const allMatch = csvData.rows.every(row => row[i] === row[columnIndex]);
      if (allMatch) {
        const otherHeader = csvData.headers[i];
        const otherField = fieldValues[otherHeader];
        if (otherField && !visited.has(i)) {
          if (otherField.mode === 'auto') {
            return generateAutoValue(i, visited);
          } else if (otherField.mode === 'existing' || otherField.mode === 'custom') {
            return otherField.value;
          }
        }
      }
    }

    return `[Auto: ${header}]`;
  };

  const handleModeChange = (header: string, mode: FieldValue['mode']) => {
    setFieldValues(prev => ({
      ...prev,
      [header]: { mode, value: '' }
    }));
  };

  const handleValueChange = (header: string, value: string) => {
    setFieldValues(prev => ({
      ...prev,
      [header]: { ...prev[header], value }
    }));
  };

  const handleSave = () => {
    if (!csvData) return;

    // Build new row array in the same order as headers
    const newRow: string[] = csvData.headers.map((header, columnIndex) => {
      const field = fieldValues[header];
      
      if (field.mode === 'auto') {
        return generateAutoValue(columnIndex);
      } else if (field.mode === 'empty') {
        return '';
      } else {
        return field.value;
      }
    });

    // Update CSV data with new row
    const updatedData = {
      ...csvData,
      rows: [...csvData.rows, newRow]
    };

    setCsvData(updatedData);
    toast.success('New row added successfully!');
    navigate(-1);
  };

  if (!csvData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <p className="text-muted-foreground">No CSV data available</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to CSV Editor
        </Button>

        <div className="mb-8">
          <h1 className="mb-2">Add New Row</h1>
          <p className="text-muted-foreground">
            Configure values for each column. Select from existing values, enter custom data, 
            leave empty, or let the system auto-generate.
          </p>
        </div>

        {/* Form */}
        <Card className="p-6 mb-6">
          <div className="space-y-6">
            {csvData.headers.map((header, columnIndex) => {
              const uniqueValues = getUniqueValuesForColumn(columnIndex);
              const currentField = fieldValues[header];

              return (
                <div key={columnIndex} className="space-y-3">
                  <Label className="text-base">{header}</Label>
                  
                  {/* Mode Selection */}
                  <div className="grid grid-cols-4 gap-2">
                    <Button
                      variant={currentField?.mode === 'existing' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleModeChange(header, 'existing')}
                      disabled={uniqueValues.length === 0}
                    >
                      Select Value
                    </Button>
                    <Button
                      variant={currentField?.mode === 'custom' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleModeChange(header, 'custom')}
                    >
                      Custom Value
                    </Button>
                    <Button
                      variant={currentField?.mode === 'empty' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleModeChange(header, 'empty')}
                    >
                      Empty
                    </Button>
                    <Button
                      variant={currentField?.mode === 'auto' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleModeChange(header, 'auto')}
                    >
                      <Sparkles className="w-4 h-4 mr-1" />
                      Auto
                    </Button>
                  </div>

                  {/* Value Input based on mode */}
                  {currentField?.mode === 'existing' && (
                    <Select
                      value={currentField.value}
                      onValueChange={(value) => handleValueChange(header, value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a value..." />
                      </SelectTrigger>
                      <SelectContent>
                        {uniqueValues.map((value, idx) => (
                          <SelectItem key={idx} value={value}>
                            {value}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}

                  {currentField?.mode === 'custom' && (
                    <Input
                      placeholder="Enter custom value..."
                      value={currentField.value}
                      onChange={(e) => handleValueChange(header, e.target.value)}
                    />
                  )}

                  {currentField?.mode === 'empty' && (
                    <div className="flex items-center h-10 px-3 rounded-md border bg-muted/50">
                      <span className="text-muted-foreground text-sm italic">
                        This field will be empty
                      </span>
                    </div>
                  )}

                  {currentField?.mode === 'auto' && (
                    <div className="flex items-center h-10 px-3 rounded-md border bg-primary/5">
                      <Sparkles className="w-4 h-4 mr-2 text-primary" />
                      <span className="text-primary text-sm">
                        System will auto-generate this value
                      </span>
                    </div>
                  )}

                  {/* Current selection preview */}
                  {currentField?.value && currentField.mode !== 'auto' && currentField.mode !== 'empty' && (
                    <Badge variant="secondary" className="text-xs">
                      Selected: {currentField.value}
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Action buttons */}
        <div className="flex gap-4">
          <Button
            variant="outline"
            size="lg"
            onClick={() => navigate(-1)}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            size="lg"
            onClick={handleSave}
            className="flex-1"
          >
            <Save className="w-5 h-5 mr-2" />
            Save New Row
          </Button>
        </div>
      </div>
    </div>
  );
}