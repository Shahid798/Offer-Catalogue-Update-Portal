import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Plus, Edit, FileSpreadsheet, Save, X } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';
import { Input } from '../components/ui/input';
import { useCSV } from '../context/CSVContext';
import { toast } from 'sonner';

interface CSVData {
  headers: string[];
  rows: string[][];
}

export default function CSVEditor() {
  const navigate = useNavigate();
  const { csvData, setCsvData, selectedFileName, setSelectedFileName } = useCSV();
  const [isLoading, setIsLoading] = useState(true);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editedData, setEditedData] = useState<string[][]>([]);

  useEffect(() => {
    // Check if CSV data already exists in context
    if (csvData) {
      setIsLoading(false);
      setEditedData(csvData.rows.map(row => [...row])); // Deep copy
      return;
    }

    // Otherwise, try to load from navigation state (first time)
    const stateData = (window.history.state?.usr?.csvData) as CSVData | undefined;
    const fileName = (window.history.state?.usr?.fileName) as string | undefined;
    
    if (stateData) {
      setCsvData(stateData);
      if (fileName) setSelectedFileName(fileName);
      setEditedData(stateData.rows.map(row => [...row])); // Deep copy
      setIsLoading(false);
    } else {
      const files = (window.history.state?.usr?.files) as File[] | undefined;
      if (files && files.length > 0) {
        // Find first CSV file
        const csvFile = files.find(file => 
          file.name.toLowerCase().endsWith('.csv')
        );
        
        if (csvFile) {
          setSelectedFileName(csvFile.name);
          parseCSV(csvFile);
        } else {
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    }
  }, [csvData, setCsvData, setSelectedFileName]);

  // Update editedData when csvData changes
  useEffect(() => {
    if (csvData) {
      setEditedData(csvData.rows.map(row => [...row]));
    }
  }, [csvData]);

  const parseCSV = async (file: File) => {
    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length === 0) {
        setIsLoading(false);
        return;
      }

      const headers = lines[0].split(',').map(h => h.trim());
      const rows = lines.slice(1).map(line => 
        line.split(',').map(cell => cell.trim())
      );

      const data = { headers, rows };
      setCsvData(data);
      setEditedData(rows.map(row => [...row])); // Deep copy
      setIsLoading(false);
    } catch (error) {
      console.error('Error parsing CSV:', error);
      setIsLoading(false);
    }
  };

  const handleAddNewRow = () => {
    // Navigate to add row form
    navigate('/add-row');
  };

  const handleEditMode = () => {
    setIsEditMode(true);
    // Reset edited data to current CSV data
    if (csvData) {
      setEditedData(csvData.rows.map(row => [...row]));
    }
  };

  const handleCancelEdit = () => {
    setIsEditMode(false);
    // Reset edited data to original
    if (csvData) {
      setEditedData(csvData.rows.map(row => [...row]));
    }
  };

  const handleSaveEdit = () => {
    if (!csvData) return;

    // Update CSV data with edited data
    const updatedData = {
      ...csvData,
      rows: editedData.map(row => [...row])
    };

    setCsvData(updatedData);
    setIsEditMode(false);
    toast.success('Changes saved successfully!');
  };

  const handleCellChange = (rowIndex: number, cellIndex: number, value: string) => {
    const newData = [...editedData];
    newData[rowIndex][cellIndex] = value;
    setEditedData(newData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <p className="text-muted-foreground">Loading CSV data...</p>
      </div>
    );
  }

  if (!csvData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-8"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Upload
          </Button>
          <Card className="p-12 text-center">
            <FileSpreadsheet className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="mb-2">No CSV File Found</h2>
            <p className="text-muted-foreground mb-6">
              Please upload a CSV file to continue.
            </p>
            <Button onClick={() => navigate('/')}>
              Go Back
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Upload
            </Button>
            <h1 className="mb-2">CSV Data Editor</h1>
            {selectedFileName && (
              <p className="text-muted-foreground">
                File: {selectedFileName}
              </p>
            )}
          </div>
        </div>

        {/* Action buttons */}
        <Card className="p-6 mb-6">
          <h2 className="mb-4">What would you like to do?</h2>
          {isEditMode ? (
            <div className="flex items-center gap-4 p-4 bg-primary/10 rounded-md">
              <div className="flex-1">
                <p className="font-medium text-primary">Edit Mode Active</p>
                <p className="text-sm text-muted-foreground">
                  Make changes to the data below and click Save when done
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="lg"
                  variant="outline"
                  onClick={handleCancelEdit}
                >
                  <X className="w-5 h-5 mr-2" />
                  Cancel
                </Button>
                <Button
                  size="lg"
                  onClick={handleSaveEdit}
                >
                  <Save className="w-5 h-5 mr-2" />
                  Save Changes
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex gap-4">
              <Button
                size="lg"
                onClick={handleAddNewRow}
                className="flex-1"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add New Row
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={handleEditMode}
                className="flex-1"
              >
                <Edit className="w-5 h-5 mr-2" />
                Edit Data
              </Button>
            </div>
          )}
        </Card>

        {/* CSV Data Table */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Current Data ({csvData.rows.length} rows)</h3>
            {isEditMode && (
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleCancelEdit}
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button
                  size="sm"
                  onClick={handleSaveEdit}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            )}
          </div>
          <div className="border rounded-md overflow-hidden">
            <div className="max-h-96 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    {csvData.headers.map((header, index) => (
                      <TableHead key={index}>{header}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {editedData.map((row, rowIndex) => (
                    <TableRow key={rowIndex}>
                      <TableCell className="font-medium">
                        {rowIndex + 1}
                      </TableCell>
                      {row.map((cell, cellIndex) => (
                        <TableCell key={cellIndex}>
                          {isEditMode ? (
                            <Input
                              value={cell}
                              onChange={(e) => handleCellChange(rowIndex, cellIndex, e.target.value)}
                              className="w-full"
                            />
                          ) : (
                            cell
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}