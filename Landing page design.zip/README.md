
  # Landing page design

  This is a code bundle for Landing page design. The original project is available at https://www.figma.com/design/2dPJtbO2fzZnYi8hihHSml/Landing-page-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  